#!/usr/bin/env python3
"""Extract representative anonymous person crops from an approved test clip."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import cv2
from ultralytics import YOLO


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("video")
    parser.add_argument("--model", default="/workspace/phone_detc_pilot/models/yolov8m.pt")
    parser.add_argument("--output", default="/workspace/phone_detc_pilot/results/person_crops")
    parser.add_argument("--seconds", type=float, default=0.0)
    parser.add_argument("--limit", type=int, default=8)
    args = parser.parse_args()

    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    capture = cv2.VideoCapture(args.video)
    capture.set(cv2.CAP_PROP_POS_MSEC, args.seconds * 1000)
    ok, frame = capture.read()
    capture.release()
    if not ok or frame is None:
        raise SystemExit("Could not decode requested frame")

    model = YOLO(args.model)
    result = model.predict(frame, imgsz=640, conf=0.35, classes=[0], device=0, verbose=False)[0]
    height, width = frame.shape[:2]
    rows = []
    boxes = sorted(
        result.boxes,
        key=lambda box: float((box.xyxy[0][2] - box.xyxy[0][0]) * (box.xyxy[0][3] - box.xyxy[0][1])),
        reverse=True,
    )[: args.limit]

    for index, box in enumerate(boxes, start=1):
        x1, y1, x2, y2 = [int(value) for value in box.xyxy[0].tolist()]
        pad_x = max(12, int((x2 - x1) * 0.12))
        pad_y = max(12, int((y2 - y1) * 0.08))
        x1, y1 = max(0, x1 - pad_x), max(0, y1 - pad_y)
        x2, y2 = min(width, x2 + pad_x), min(height, y2 + pad_y)
        crop = frame[y1:y2, x1:x2]
        path = output / f"person_{index:02d}.jpg"
        cv2.imwrite(str(path), crop, [cv2.IMWRITE_JPEG_QUALITY, 92])
        rows.append(
            {
                "crop": str(path),
                "bbox": [x1, y1, x2, y2],
                "person_confidence": round(float(box.conf[0]), 4),
                "shape": list(crop.shape),
            }
        )

    manifest = output / "manifest.json"
    manifest.write_text(json.dumps(rows, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"count": len(rows), "manifest": str(manifest)}, indent=2))


if __name__ == "__main__":
    main()
