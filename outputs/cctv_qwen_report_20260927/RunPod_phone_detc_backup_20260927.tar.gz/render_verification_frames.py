#!/usr/bin/env python3
"""Render selected frames with person and phone detections for visual QA."""

from pathlib import Path
import argparse
import cv2
from ultralytics import YOLO


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("video")
    parser.add_argument("--root", default="/workspace/phone_detc_pilot")
    parser.add_argument("--times", default="4,10,20,30,40,50,60")
    parser.add_argument("--output-dir", default="/workspace/phone_detc_pilot/results/verification_frames")
    args = parser.parse_args()

    root = Path(args.root)
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    person = YOLO(str(root / "models/yolov8m.pt"))
    phones = [
        ("v5", YOLO(str(root / "models/phone_v5_best.pt")), (0, 0, 255)),
        ("model2", YOLO(str(root / "models/phone_model2_best.pt")), (255, 0, 255)),
    ]
    capture = cv2.VideoCapture(args.video)
    fps = capture.get(cv2.CAP_PROP_FPS)

    for second in [float(value) for value in args.times.split(",")]:
        capture.set(cv2.CAP_PROP_POS_FRAMES, round(second * fps))
        ok, frame = capture.read()
        if not ok:
            continue
        person_result = person.predict(frame, imgsz=640, conf=0.30, classes=[0], device=0, verbose=False)[0]
        for box in person_result.boxes.xyxy.cpu().tolist():
            x1, y1, x2, y2 = map(int, box)
            cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 220, 0), 3)
        for model_name, model, color in phones:
            result = model.predict(frame, imgsz=640, conf=0.25, device=0, verbose=False)[0]
            for box, confidence in zip(result.boxes.xyxy.cpu().tolist(), result.boxes.conf.cpu().tolist()):
                x1, y1, x2, y2 = map(int, box)
                cv2.rectangle(frame, (x1, y1), (x2, y2), color, 4)
                cv2.putText(frame, f"{model_name} phone {confidence:.2f}", (x1, max(30, y1 - 8)),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.8, color, 2, cv2.LINE_AA)
        cv2.putText(frame, f"t={second:.0f}s", (30, 55), cv2.FONT_HERSHEY_SIMPLEX, 1.4,
                    (255, 255, 255), 3, cv2.LINE_AA)
        cv2.imwrite(str(output_dir / f"frame_{int(second):02d}s.jpg"), frame)
    capture.release()


if __name__ == "__main__":
    main()
