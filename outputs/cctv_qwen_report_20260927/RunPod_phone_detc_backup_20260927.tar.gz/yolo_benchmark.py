#!/usr/bin/env python3
"""Benchmark the existing PHONE_DETC YOLO stages without camera credentials."""

from __future__ import annotations

import argparse
import json
import statistics
import time
from pathlib import Path

import cv2
import numpy as np
import torch
from ultralytics import YOLO


def sync() -> None:
    if torch.cuda.is_available():
        torch.cuda.synchronize()


def percentile(values: list[float], fraction: float) -> float:
    ordered = sorted(values)
    index = min(len(ordered) - 1, round((len(ordered) - 1) * fraction))
    return ordered[index]


def measure(model: YOLO, frame: np.ndarray, *, iterations: int, classes=None) -> dict:
    for _ in range(5):
        model.predict(frame, imgsz=640, conf=0.25, classes=classes, device=0, verbose=False)
    sync()

    samples = []
    detections = 0
    for _ in range(iterations):
        started = time.perf_counter()
        result = model.predict(
            frame, imgsz=640, conf=0.25, classes=classes, device=0, verbose=False
        )[0]
        sync()
        samples.append((time.perf_counter() - started) * 1000)
        detections += len(result.boxes)

    return {
        "iterations": iterations,
        "mean_ms": round(statistics.mean(samples), 2),
        "median_ms": round(statistics.median(samples), 2),
        "p95_ms": round(percentile(samples, 0.95), 2),
        "max_ms": round(max(samples), 2),
        "mean_detections": round(detections / iterations, 2),
    }


def load_frame(source: str | None) -> tuple[np.ndarray, str]:
    if not source:
        return np.zeros((1440, 2560, 3), dtype=np.uint8), "synthetic_2560x1440"

    path = Path(source)
    if not path.exists():
        raise SystemExit(f"Source does not exist: {path}")

    if path.suffix.lower() in {".jpg", ".jpeg", ".png", ".webp"}:
        frame = cv2.imread(str(path))
    else:
        capture = cv2.VideoCapture(str(path))
        ok, frame = capture.read()
        capture.release()
        if not ok:
            frame = None

    if frame is None:
        raise SystemExit(f"Could not decode a frame from: {path}")
    return frame, str(path)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--models", default="/workspace/phone_detc_pilot/models")
    parser.add_argument("--source")
    parser.add_argument("--iterations", type=int, default=100)
    parser.add_argument(
        "--output", default="/workspace/phone_detc_pilot/results/yolo_benchmark.json"
    )
    args = parser.parse_args()

    model_dir = Path(args.models)
    frame, source_name = load_frame(args.source)
    specifications = [
        ("person_yolov8m", model_dir / "yolov8m.pt", [0]),
        ("phone_v5", model_dir / "phone_v5_best.pt", None),
        ("phone_model2", model_dir / "phone_model2_best.pt", None),
    ]

    report = {
        "source": source_name,
        "frame_shape": list(frame.shape),
        "device": torch.cuda.get_device_name(0) if torch.cuda.is_available() else "cpu",
        "torch": torch.__version__,
        "models": {},
    }

    for name, path, classes in specifications:
        model = YOLO(str(path))
        report["models"][name] = measure(
            model, frame, iterations=args.iterations, classes=classes
        )
        del model
        if torch.cuda.is_available():
            torch.cuda.empty_cache()

    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
