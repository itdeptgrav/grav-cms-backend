#!/usr/bin/env python3
"""Benchmark batched Qwen-VL decisions over all person crops in one frame."""

from __future__ import annotations

import argparse
import json
import statistics
import time
from pathlib import Path

import torch
from PIL import Image
from qwen_vl_utils import process_vision_info
from transformers import AutoProcessor, Qwen2_5_VLForConditionalGeneration


PROMPT = """Classify only what is visibly observable in this CCTV person crop.
Return exactly one number and nothing else.
1 = using a phone
2 = working with a laptop, paper, pen, document, tool, or machine
3 = visibly talking with another person
4 = no observable task in this frame
5 = uncertain because the evidence is too small, blocked, or ambiguous
"""


def summary(values: list[float]) -> dict:
    ordered = sorted(values)
    p95 = ordered[min(len(ordered) - 1, round((len(ordered) - 1) * 0.95))]
    return {
        "mean_ms": round(statistics.mean(values), 2),
        "median_ms": round(statistics.median(values), 2),
        "p95_ms": round(p95, 2),
        "max_ms": round(max(values), 2),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("crop_dir")
    parser.add_argument(
        "--model", default="/workspace/phone_detc_pilot/models/Qwen2.5-VL-3B-Instruct"
    )
    parser.add_argument("--iterations", type=int, default=10)
    parser.add_argument(
        "--output", default="/workspace/phone_detc_pilot/results/qwen_batch.json"
    )
    args = parser.parse_args()

    paths = sorted(Path(args.crop_dir).glob("person_*.jpg"))
    if not paths:
        raise SystemExit("No person_*.jpg crops found")
    images = [Image.open(path).convert("RGB") for path in paths]

    model = Qwen2_5_VLForConditionalGeneration.from_pretrained(
        args.model,
        torch_dtype=torch.bfloat16,
        device_map="cuda",
        attn_implementation="sdpa",
    ).eval()
    processor = AutoProcessor.from_pretrained(
        args.model,
        min_pixels=256 * 28 * 28,
        max_pixels=512 * 28 * 28,
    )

    messages_batch = []
    texts = []
    image_inputs = []
    for image in images:
        messages = [
            {
                "role": "user",
                "content": [
                    {"type": "image", "image": image},
                    {"type": "text", "text": PROMPT},
                ],
            }
        ]
        messages_batch.append(messages)
        texts.append(
            processor.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
        )
        prepared_images, _ = process_vision_info(messages)
        image_inputs.extend(prepared_images)

    timings = []
    answers = []
    for iteration in range(args.iterations + 2):
        started = time.perf_counter()
        inputs = processor(
            text=texts,
            images=image_inputs,
            videos=None,
            padding=True,
            return_tensors="pt",
        ).to("cuda")
        with torch.inference_mode():
            generated = model.generate(
                **inputs, max_new_tokens=2, do_sample=False, use_cache=True
            )
        torch.cuda.synchronize()
        elapsed = (time.perf_counter() - started) * 1000
        trimmed = generated[:, inputs.input_ids.shape[1] :]
        decoded = processor.batch_decode(
            trimmed, skip_special_tokens=True, clean_up_tokenization_spaces=False
        )
        if iteration >= 2:
            timings.append(elapsed)
            answers.append([answer.strip() for answer in decoded])

    report = {
        "batch_size": len(images),
        "files": [path.name for path in paths],
        "device": torch.cuda.get_device_name(0),
        "iterations": args.iterations,
        "total_batch": summary(timings),
        "last_answers": answers[-1],
        "stable_across_runs": all(item == answers[0] for item in answers),
    }
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
