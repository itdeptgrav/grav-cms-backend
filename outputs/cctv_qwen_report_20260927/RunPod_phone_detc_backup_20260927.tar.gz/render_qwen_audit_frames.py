#!/usr/bin/env python3
"""Render every Qwen sample frame with the recorded person activity labels."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import cv2


COLORS = {
    "using_phone": (40, 40, 230),
    "working": (45, 180, 65),
    "talking_or_interacting": (25, 150, 235),
    "no_observable_task": (200, 120, 30),
    "uncertain": (130, 130, 130),
}

SHORT = {
    "using_phone": "PHONE",
    "working": "WORKING",
    "talking_or_interacting": "TALKING",
    "no_observable_task": "NO TASK",
    "uncertain": "UNCERTAIN",
}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("video")
    parser.add_argument("report")
    parser.add_argument("output_dir")
    args = parser.parse_args()

    report = json.loads(Path(args.report).read_text(encoding="utf-8"))
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    capture = cv2.VideoCapture(args.video)
    if not capture.isOpened():
        raise SystemExit("Could not open video")

    for index, sample in enumerate(report["timeline"]):
        capture.set(cv2.CAP_PROP_POS_FRAMES, sample["frame"])
        ok, frame = capture.read()
        if not ok:
            continue

        for observation in sample["observations"]:
            x1, y1, x2, y2 = [int(v) for v in observation["box"]]
            label = observation["label"]
            color = COLORS.get(label, COLORS["uncertain"])
            caption = f'ID {observation["track_id"]}  {SHORT.get(label, label.upper())}'
            cv2.rectangle(frame, (x1, y1), (x2, y2), color, 5)
            (tw, th), baseline = cv2.getTextSize(caption, cv2.FONT_HERSHEY_SIMPLEX, 0.9, 2)
            top = max(0, y1 - th - baseline - 10)
            cv2.rectangle(frame, (x1, top), (min(frame.shape[1], x1 + tw + 12), y1), color, -1)
            cv2.putText(frame, caption, (x1 + 6, y1 - baseline - 4),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.9, (255, 255, 255), 2, cv2.LINE_AA)

        stamp = f'Qwen sample {index + 1:02d}   t={sample["time_seconds"]:.1f}s   people={sample["people"]}'
        cv2.rectangle(frame, (18, 18), (820, 78), (20, 29, 45), -1)
        cv2.putText(frame, stamp, (35, 60), cv2.FONT_HERSHEY_SIMPLEX, 1.05,
                    (255, 255, 255), 2, cv2.LINE_AA)
        resized = cv2.resize(frame, (1280, 720), interpolation=cv2.INTER_AREA)
        cv2.imwrite(str(output_dir / f'sample_{index + 1:02d}_{sample["time_seconds"]:05.1f}s.jpg'),
                    resized, [cv2.IMWRITE_JPEG_QUALITY, 88])

    capture.release()
    print(f"Rendered {len(list(output_dir.glob('*.jpg')))} frames")


if __name__ == "__main__":
    main()
