#!/usr/bin/env python3
"""Measure end-to-end Qwen-VL activity-choice latency on a person crop."""

from __future__ import annotations

import argparse
import json
import statistics
import time
from pathlib import Path

import numpy as np
import torch
from PIL import Image
from qwen_vl_utils import process_vision_info
from transformers import AutoProcessor, Qwen2_5_VLForConditionalGeneration


PROMPT = """Classify only what is visibly observable in this CCTV person crop.
Return exactly one number and nothing else.
1 = using a phone
2 = working with a laptop, paper, pen, document, tool, or machine
3 = visibly talking with another person
4 = no observable task in this frame
5 = uncertain because the evidence is too small, blocked, or ambiguous
"""


def percentile(values: list[float], fraction: float) -> float:
    ordered = sorted(values)
    index = min(len(ordered) - 1, round((len(ordered) - 1) * fraction))
    return ordered[index]


def stats(values: list[float]) -> dict:
    return {
        "mean_ms": round(statistics.mean(values), 2),
        "median_ms": round(statistics.median(values), 2),
        "p95_ms": round(percentile(values, 0.95), 2),
        "max_ms": round(max(values), 2),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--model",
        default="/workspace/phone_detc_pilot/models/Qwen2.5-VL-3B-Instruct",
    )
    parser.add_argument("--image")
    parser.add_argument("--iterations", type=int, default=20)
    parser.add_argument(
        "--output", default="/workspace/phone_detc_pilot/results/qwen_benchmark.json"
    )
    args = parser.parse_args()

    if args.image:
        image = Image.open(args.image).convert("RGB")
        source = args.image
    else:
        image = Image.fromarray(np.full((640, 480, 3), 127, dtype=np.uint8))
        source = "synthetic_480x640"

    model = Qwen2_5_VLForConditionalGeneration.from_pretrained(
        args.model,
        torch_dtype=torch.bfloat16,
        device_map="cuda",
        attn_implementation="sdpa",
    ).eval()
    processor = AutoProcessor.from_pretrained(
        args.model,
        min_pixels=256 * 28 * 28,
        max_pixels=512 * 28 * 28,
    )

    prepare_ms: list[float] = []
    inference_ms: list[float] = []
    total_ms: list[float] = []
    answers: list[str] = []

    for index in range(args.iterations + 3):
        started = time.perf_counter()
        messages = [
            {
                "role": "user",
                "content": [
                    {"type": "image", "image": image},
                    {"type": "text", "text": PROMPT},
                ],
            }
        ]
        text = processor.apply_chat_template(
            messages, tokenize=False, add_generation_prompt=True
        )
        image_inputs, video_inputs = process_vision_info(messages)
        inputs = processor(
            text=[text],
            images=image_inputs,
            videos=video_inputs,
            padding=True,
            return_tensors="pt",
        ).to("cuda")
        prepared = time.perf_counter()
        with torch.inference_mode():
            generated = model.generate(
                **inputs,
                max_new_tokens=2,
                do_sample=False,
                use_cache=True,
            )
        torch.cuda.synchronize()
        finished = time.perf_counter()
        trimmed = generated[:, inputs.input_ids.shape[1] :]
        answer = processor.batch_decode(
            trimmed, skip_special_tokens=True, clean_up_tokenization_spaces=False
        )[0].strip()

        if index >= 3:
            prepare_ms.append((prepared - started) * 1000)
            inference_ms.append((finished - prepared) * 1000)
            total_ms.append((finished - started) * 1000)
            answers.append(answer)

    report = {
        "source": source,
        "image_size": list(image.size),
        "model": args.model,
        "device": torch.cuda.get_device_name(0),
        "iterations": args.iterations,
        "prepare": stats(prepare_ms),
        "inference": stats(inference_ms),
        "total": stats(total_ms),
        "answers": answers,
    }
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
