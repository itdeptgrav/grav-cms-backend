#!/usr/bin/env python3
"""Private MJPEG preview for YOLO tracking plus Qwen activity labels."""

from __future__ import annotations

import argparse
import json
import re
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import cv2
import numpy as np
import torch
from PIL import Image
from qwen_vl_utils import process_vision_info
from transformers import AutoProcessor, Qwen2_5_VLForConditionalGeneration
from ultralytics import YOLO


PROMPT = """Classify only the visible activity of the main person in this CCTV crop.
Return exactly one digit:
1 = using a phone
2 = working with a laptop, paper, pen, document, tool, or machine
3 = visibly talking or interacting with another person
4 = no observable task
5 = uncertain because evidence is small, blocked, or ambiguous
Answer:"""

LABELS = {
    "1": "PHONE",
    "2": "WORKING",
    "3": "TALKING",
    "4": "NO TASK",
    "5": "UNCERTAIN",
}

COLORS = {
    "PHONE": (40, 40, 230),
    "WORKING": (45, 180, 65),
    "TALKING": (25, 150, 235),
    "NO TASK": (200, 120, 30),
    "UNCERTAIN": (130, 130, 130),
    "ANALYZING": (160, 160, 160),
}

lock = threading.Lock()
latest_jpeg = b""
status = {
    "stage": "starting",
    "message": "Starting preview service",
    "frame": 0,
    "total_frames": 0,
    "video_seconds": 0,
    "progress": 0,
}


def update_frame(frame):
    global latest_jpeg
    ok, encoded = cv2.imencode(".jpg", frame, [cv2.IMWRITE_JPEG_QUALITY, 82])
    if ok:
        with lock:
            latest_jpeg = encoded.tobytes()


def placeholder(message):
    frame = np.full((720, 1280, 3), (24, 31, 45), dtype=np.uint8)
    cv2.putText(frame, "CCTV Qwen Live Preview", (70, 290), cv2.FONT_HERSHEY_SIMPLEX,
                1.55, (255, 255, 255), 3, cv2.LINE_AA)
    cv2.putText(frame, message, (70, 370), cv2.FONT_HERSHEY_SIMPLEX,
                1.0, (130, 190, 255), 2, cv2.LINE_AA)
    update_frame(frame)


def crop_person(frame, box, fraction=0.18):
    height, width = frame.shape[:2]
    x1, y1, x2, y2 = [float(value) for value in box]
    dx, dy = (x2 - x1) * fraction, (y2 - y1) * fraction
    x1, y1 = max(0, int(x1 - dx)), max(0, int(y1 - dy))
    x2, y2 = min(width, int(x2 + dx)), min(height, int(y2 + dy))
    return frame[y1:y2, x1:x2]


def classify(model, processor, crop):
    image = Image.fromarray(cv2.cvtColor(crop, cv2.COLOR_BGR2RGB))
    messages = [{"role": "user", "content": [
        {"type": "image", "image": image},
        {"type": "text", "text": PROMPT},
    ]}]
    text = processor.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
    image_inputs, _ = process_vision_info(messages)
    inputs = processor(text=[text], images=image_inputs, videos=None,
                       padding=True, return_tensors="pt").to("cuda")
    with torch.inference_mode():
        generated = model.generate(**inputs, max_new_tokens=4, do_sample=False, use_cache=True)
    decoded = processor.batch_decode(
        generated[:, inputs.input_ids.shape[1]:], skip_special_tokens=True
    )[0].strip()
    match = re.search(r"[1-5]", decoded)
    return LABELS[match.group(0)] if match else "UNCERTAIN"


def draw_preview(frame, boxes, ids, labels, frame_index, total_frames, fps, stage):
    for track_id, box in zip(ids, boxes):
        x1, y1, x2, y2 = map(int, box)
        label = labels.get(track_id, "ANALYZING")
        color = COLORS[label]
        caption = f"ID {track_id}  {label}"
        cv2.rectangle(frame, (x1, y1), (x2, y2), color, 5)
        (tw, th), baseline = cv2.getTextSize(caption, cv2.FONT_HERSHEY_SIMPLEX, 0.85, 2)
        top = max(0, y1 - th - baseline - 10)
        cv2.rectangle(frame, (x1, top), (min(frame.shape[1], x1 + tw + 12), y1), color, -1)
        cv2.putText(frame, caption, (x1 + 6, y1 - baseline - 4),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.85, (255, 255, 255), 2, cv2.LINE_AA)

    progress = frame_index / max(total_frames, 1)
    banner = f"{stage}   t={frame_index / fps:05.1f}s   frame {frame_index}/{total_frames}   {progress * 100:05.1f}%"
    cv2.rectangle(frame, (16, 16), (1120, 78), (20, 29, 45), -1)
    cv2.putText(frame, banner, (34, 58), cv2.FONT_HERSHEY_SIMPLEX, 1.0,
                (255, 255, 255), 2, cv2.LINE_AA)
    return cv2.resize(frame, (1280, 720), interpolation=cv2.INTER_AREA)


def analyze(args):
    global status
    try:
        placeholder("Loading YOLO person tracker...")
        with lock:
            status.update(stage="loading", message="Loading YOLO person tracker")
        person_model = YOLO(args.person_model)

        placeholder("Loading Qwen 2.5-VL 3B into GPU memory...")
        with lock:
            status.update(stage="loading", message="Loading Qwen 2.5-VL 3B into GPU memory")
        qwen = Qwen2_5_VLForConditionalGeneration.from_pretrained(
            args.qwen_model, torch_dtype=torch.bfloat16, device_map="cuda",
            attn_implementation="sdpa",
        ).eval()
        processor = AutoProcessor.from_pretrained(
            args.qwen_model, min_pixels=128 * 28 * 28, max_pixels=384 * 28 * 28,
        )

        capture = cv2.VideoCapture(args.video)
        if not capture.isOpened():
            raise RuntimeError("Could not open video")
        fps = capture.get(cv2.CAP_PROP_FPS) or 25.0
        total_frames = int(capture.get(cv2.CAP_PROP_FRAME_COUNT))
        sample_every = max(1, round(fps * args.sample_seconds))
        labels = {}
        frame_index = 0
        started = time.perf_counter()
        with lock:
            status.update(stage="running", message="Analyzing video", total_frames=total_frames)

        while True:
            ok, frame = capture.read()
            if not ok:
                break
            result = person_model.track(
                frame, persist=True, tracker="bytetrack.yaml", classes=[0], imgsz=640,
                conf=0.30, iou=0.50, device=0, verbose=False,
            )[0]
            boxes = result.boxes.xyxy.cpu().tolist() if result.boxes is not None else []
            if result.boxes is not None and result.boxes.id is not None:
                ids = [int(value) for value in result.boxes.id.cpu().tolist()]
            else:
                ids = list(range(len(boxes)))

            if frame_index % sample_every == 0:
                for track_id, box in zip(ids, boxes):
                    labels[track_id] = "ANALYZING"
                    update_frame(draw_preview(frame.copy(), boxes, ids, labels, frame_index,
                                              total_frames, fps, "QWEN UPDATE"))
                    crop = crop_person(frame, box)
                    if crop.size:
                        labels[track_id] = classify(qwen, processor, crop)

            preview = draw_preview(frame.copy(), boxes, ids, labels, frame_index,
                                   total_frames, fps, "LIVE ANALYSIS")
            update_frame(preview)
            with lock:
                status.update(
                    frame=frame_index,
                    total_frames=total_frames,
                    video_seconds=round(frame_index / fps, 2),
                    progress=round(frame_index / max(total_frames, 1) * 100, 1),
                    wall_seconds=round(time.perf_counter() - started, 1),
                    people=len(boxes),
                )
            frame_index += 1

        capture.release()
        with lock:
            status.update(stage="complete", message="Video analysis complete", progress=100)
    except Exception as exc:
        placeholder(f"Error: {exc}")
        with lock:
            status.update(stage="error", message=str(exc))


PAGE = """<!doctype html>
<html><head><meta charset="utf-8"><title>CCTV Qwen Preview</title>
<style>
body{margin:0;background:#0f1420;color:#fff;font-family:Arial,sans-serif}
.wrap{max-width:1320px;margin:22px auto;padding:0 18px}
h1{font-size:24px;margin:0 0 12px}.status{color:#b8c7dc;margin-bottom:12px}
img{width:100%;background:#182032;border:1px solid #344158;border-radius:8px}
.bar{height:10px;background:#2b3445;border-radius:8px;overflow:hidden;margin-top:12px}
.fill{height:100%;width:0;background:#4d8cf7;transition:width .2s}
</style></head><body><div class="wrap"><h1>Qwen CCTV Activity Preview</h1>
<div class="status" id="status">Connecting...</div><img src="/stream" alt="Live annotated preview">
<div class="bar"><div class="fill" id="fill"></div></div></div>
<script>setInterval(async()=>{try{const r=await fetch('/status');const s=await r.json();
document.getElementById('status').textContent=`${s.stage}: ${s.message} | video ${s.video_seconds||0}s | frame ${s.frame||0}/${s.total_frames||0} | people ${s.people||0} | wall ${s.wall_seconds||0}s`;
document.getElementById('fill').style.width=`${s.progress||0}%`;}catch(e){}},500);</script></body></html>"""


class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path == "/":
            body = PAGE.encode()
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        elif self.path == "/status":
            with lock:
                body = json.dumps(status).encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        elif self.path == "/stream":
            self.send_response(200)
            self.send_header("Content-Type", "multipart/x-mixed-replace; boundary=frame")
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            try:
                while True:
                    with lock:
                        frame = latest_jpeg
                    if frame:
                        self.wfile.write(b"--frame\r\nContent-Type: image/jpeg\r\n\r\n" + frame + b"\r\n")
                    time.sleep(0.15)
            except (BrokenPipeError, ConnectionResetError):
                pass
        else:
            self.send_error(404)

    def log_message(self, format, *args):
        return


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--video", required=True)
    parser.add_argument("--person-model", required=True)
    parser.add_argument("--qwen-model", required=True)
    parser.add_argument("--sample-seconds", type=float, default=1.0)
    parser.add_argument("--port", type=int, default=7860)
    args = parser.parse_args()
    placeholder("Preview service is starting...")
    threading.Thread(target=analyze, args=(args,), daemon=True).start()
    ThreadingHTTPServer(("127.0.0.1", args.port), Handler).serve_forever()


if __name__ == "__main__":
    main()
