#!/usr/bin/env python3
"""Analyze a complete CCTV clip with person YOLO and Qwen activity classification."""

from __future__ import annotations

import argparse
import json
import re
import time
from collections import Counter, defaultdict
from pathlib import Path

import cv2
import torch
from PIL import Image
from qwen_vl_utils import process_vision_info
from transformers import AutoProcessor, Qwen2_5_VLForConditionalGeneration
from ultralytics import YOLO


PROMPT = """Classify only the visible activity of the main person in this CCTV crop.
Return exactly one digit:
1 = using a phone
2 = working with a laptop, paper, pen, document, tool, or machine
3 = visibly talking or interacting with another person
4 = no observable task
5 = uncertain because evidence is small, blocked, or ambiguous
Answer:"""

LABELS = {
    "1": "using_phone",
    "2": "working",
    "3": "talking_or_interacting",
    "4": "no_observable_task",
    "5": "uncertain",
}


def expanded_crop(frame, box, fraction=0.18):
    height, width = frame.shape[:2]
    x1, y1, x2, y2 = [float(value) for value in box]
    dx, dy = (x2 - x1) * fraction, (y2 - y1) * fraction
    x1, y1 = max(0, int(x1 - dx)), max(0, int(y1 - dy))
    x2, y2 = min(width, int(x2 + dx)), min(height, int(y2 + dy))
    return frame[y1:y2, x1:x2], [x1, y1, x2, y2]


def qwen_classify(model, processor, image):
    messages = [{"role": "user", "content": [
        {"type": "image", "image": image},
        {"type": "text", "text": PROMPT},
    ]}]
    text = processor.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
    image_inputs, _ = process_vision_info(messages)
    inputs = processor(
        text=[text], images=image_inputs, videos=None, padding=True, return_tensors="pt"
    ).to("cuda")
    with torch.inference_mode():
        generated = model.generate(
            **inputs, max_new_tokens=4, do_sample=False, use_cache=True
        )
    trimmed = generated[:, inputs.input_ids.shape[1]:]
    answer = processor.batch_decode(trimmed, skip_special_tokens=True)[0].strip()
    match = re.search(r"[1-5]", answer)
    return (match.group(0) if match else "5"), answer


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("video")
    parser.add_argument("--root", default="/workspace/phone_detc_pilot")
    parser.add_argument("--sample-seconds", type=float, default=1.0)
    parser.add_argument("--output", default="/workspace/phone_detc_pilot/results/full_clip_analysis.json")
    args = parser.parse_args()

    root = Path(args.root)
    capture = cv2.VideoCapture(args.video)
    if not capture.isOpened():
        raise SystemExit(f"Could not open {args.video}")
    fps = capture.get(cv2.CAP_PROP_FPS) or 25.0
    frame_count = int(capture.get(cv2.CAP_PROP_FRAME_COUNT))
    width = int(capture.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(capture.get(cv2.CAP_PROP_FRAME_HEIGHT))
    sample_every = max(1, round(fps * args.sample_seconds))

    person_model = YOLO(str(root / "models/yolov8m.pt"))
    print("Loading Qwen...", flush=True)
    qwen = Qwen2_5_VLForConditionalGeneration.from_pretrained(
        str(root / "models/Qwen2.5-VL-3B-Instruct"),
        torch_dtype=torch.bfloat16,
        device_map="cuda",
        attn_implementation="sdpa",
    ).eval()
    processor = AutoProcessor.from_pretrained(
        str(root / "models/Qwen2.5-VL-3B-Instruct"),
        min_pixels=128 * 28 * 28,
        max_pixels=384 * 28 * 28,
    )

    timeline = []
    track_counts = defaultdict(Counter)
    frames_with_people = 0
    total_person_detections = 0
    started = time.perf_counter()
    frame_index = 0

    while True:
        ok, frame = capture.read()
        if not ok:
            break

        person_result = person_model.track(
            frame, persist=True, tracker="bytetrack.yaml", classes=[0], imgsz=640,
            conf=0.30, iou=0.50, device=0, verbose=False,
        )[0]
        boxes = person_result.boxes.xyxy.cpu().tolist() if person_result.boxes is not None else []
        if person_result.boxes is not None and person_result.boxes.id is not None:
            ids = [int(value) for value in person_result.boxes.id.cpu().tolist()]
        else:
            ids = list(range(len(boxes)))

        total_person_detections += len(boxes)
        frames_with_people += int(bool(boxes))

        if frame_index % sample_every == 0:
            observations = []
            for track_id, box in zip(ids, boxes):
                crop, crop_box = expanded_crop(frame, box)
                if crop.size == 0:
                    continue
                label, raw = qwen_classify(
                    qwen, processor, Image.fromarray(cv2.cvtColor(crop, cv2.COLOR_BGR2RGB))
                )
                name = LABELS[label]
                track_counts[str(track_id)][name] += 1
                observations.append({
                    "track_id": track_id,
                    "label": name,
                    "source": "qwen",
                    "raw_answer": raw,
                    "box": [round(value, 1) for value in box],
                })
            timeline.append({
                "time_seconds": round(frame_index / fps, 2),
                "frame": frame_index,
                "people": len(boxes),
                "observations": observations,
            })
            print(
                f"sample {frame_index / fps:.1f}s people={len(boxes)}",
                flush=True,
            )

        frame_index += 1

    capture.release()
    elapsed = time.perf_counter() - started
    aggregate = Counter()
    tracks = {}
    for track_id, counts in track_counts.items():
        aggregate.update(counts)
        total = sum(counts.values())
        dominant = counts.most_common(1)[0][0]
        tracks[track_id] = {
            "samples": total,
            "counts": dict(counts),
            "dominant_activity": dominant,
            "dominant_share": round(counts[dominant] / total, 3),
        }

    report = {
        "source": args.video,
        "video": {
            "width": width,
            "height": height,
            "fps": round(fps, 3),
            "declared_frames": frame_count,
            "processed_frames": frame_index,
            "duration_seconds": round(frame_index / fps, 2),
        },
        "method": {
            "person_detection_and_tracking": "YOLO every frame",
            "activity_and_phone_classification": "Qwen only",
            "qwen_sampling_seconds": args.sample_seconds,
            "labels": LABELS,
        },
        "performance": {
            "wall_seconds_excluding_model_load": round(elapsed, 2),
            "effective_fps": round(frame_index / elapsed, 2),
        },
        "detection_summary": {
            "frames_with_people": frames_with_people,
            "total_person_detections": total_person_detections,
            "average_people_per_frame": round(total_person_detections / max(frame_index, 1), 2),
        },
        "activity_observations": dict(aggregate),
        "tracks": tracks,
        "timeline": timeline,
    }
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({key: value for key, value in report.items() if key != "timeline"}, indent=2))


if __name__ == "__main__":
    main()
